import React from 'react'
import { useRef } from 'react'
import './Home.css'

export const Home = () => {

   const bg=useRef("")
   
  
   function changeColorToYellow(){
    bg.current.style.backgroundColor="#FFCC00"
   }
   function changeColorToBlack(){
    bg.current.style.backgroundColor="#000a17"
   }
    return(
        <>
        <div className='maindiv'>
            <div className='container'>
                <div className='divyellow' ref={bg}>
                   <button type="button"  class="btn btn-dark  btn1" onClick={changeColorToBlack}>Dark</button>
                    
                </div>

                <div className='divblack' ref={bg}>
                   <button type="button" class="btn btn-warning btn2" onClick={changeColorToYellow}>Warning</button>
                   whatever the changes will be made will made in this div 
                </div>
            </div>   
        </div>
            
        </>
    )
}