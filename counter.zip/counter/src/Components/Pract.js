const arr=[1,4,89,67,56,99,36]
a=arr.sort()
console.log(a)