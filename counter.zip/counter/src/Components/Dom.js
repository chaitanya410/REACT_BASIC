// import React from 'react'
// import { useRef } from 'react';
// export const Dom = () => {
//     const inputElem=useRef("")
//     const changeStyle=() =>{
//         inputElem.current.style.backgroundColor="red"
//         inputElem.current.focus()
//     };
//     return(

        
//         <>
//           <input ref={inputElem}
//                  type='text'
//                  >
//           </input>
//           <button onClick={changeStyle}>Submit</button>
//         </>
//     )
// }

import React, { useRef } from 'react'

export const Dom = () => {

    const inputelem = useRef("")
    function clickHandler(){
        inputelem.current.style.backgroundColor="blue"
        inputelem.current.focus()
    }
    return(
        <>
           <div>
                 <input type='text' ref={inputelem}></input>
           </div>
           <div>
                <button onClick={clickHandler}> Submit </button>
           </div>
        </>
    )
}