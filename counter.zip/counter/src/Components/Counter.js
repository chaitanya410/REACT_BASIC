import React from "react"
import "./Counter.css"
import {useState} from "react"

export const Counter = () => {

    const [count,setCount]=useState(0)

    return(
        <>
            <div className="display"> QTY : {count} </div><br></br>
            <div className="btns">
                <button onClick={()=>{
                    setCount(count+1)
                }}> Increment </button><br></br>
                <button onClick={()=>{
                    if (count>0){
                        setCount(count-1)
                    }
                }}> Decrement  </button>
            </div>

        </>
    )
}