// // import React from 'react'
// // import {useState,useEffect,useRef} from 'react'
// // export const Render = () => {

// //     const[mydata,setMyData]=useState("");
// //     // const[countme, setCountme]=useState(0)
// //     const countme=useRef(0);

// //     useEffect(()=>{
// //         // setCountme(countme+1)
// //         countme.current=countme.current +1
        
// //          return(
// //             console.log("I am cleaned up ")
// //          )}
// //         )

// //      return(
// //         <>
// //            <input type="text" value={mydata} onChange={(e)=>{
// //                      setMyData(e.target.value)
// //            }}></input><br></br>

// //            <p>Number of time i have rendered {countme.current}</p>

// //         </>
// //      )
// // }

// import React, { useEffect,useRef,useState } from 'react'
// export const Render = () => {
  
//     const[mydata,setMyData]=useState("")
//     const cnt=useRef(0)
//     useEffect(()=>{
//         cnt.current=cnt.current+1
//     })
//     return(
//         <>
//            <div>
//                <input type="text" value={mydata} onChange={(e)=>{
//                   setMyData(e.target.value)
//                }}></input> 
//            </div>
//            <div>
//                <p>I have rendered : {cnt.current} </p>
//            </div>
//         </>
//     )
// }

// import React from 'react'
// import { useState,useEffect,useRef } from 'react'
// export const Render = () => {
//     const[mydata,setMydata]=useState("")
//     const count=useRef(0)
//     useEffect(()=>{
//         count.current=count.current+1
//     })
//     return(
//         <>
//             <div>
//                 <input type='text'value={mydata}  onChange={(e)=>{
//                     setMydata(e.target.value)
//                 }}>
                    
//                 </input>
//             </div>
//             <p> the number of time i have rendered : {count.current}</p>
//         </>
//     )
// }


import React from 'react'
import { useState,useRef,useEffect } from 'react'


export const Render = () => {

    const[data,setdata]=useState(" ")
    const Inputelem = useRef(0)

    useEffect(()=>{
        Inputelem.current=Inputelem.current+1
    })
    return(
        <>
           <div>
             <input type='text'  value={data} onChange={(e)=>{
                setdata(e.target.value)
             }} ></input>
           </div>
           <div> <p>i have rendered : {Inputelem.current}</p></div>
          
        </>
    )
}