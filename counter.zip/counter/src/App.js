import React from "react"
import { Counter } from "./Components/Counter"
import { Render } from "./Components/Render"
import {Dom} from "./Components/Dom"
function App()  {

  return(

    <div className="App">
     <Counter/>
     <Render/>
     <Dom/>
    </div>
  )
}

export default App 

// import React from 'react'

// function App(){
//   return(
//     <div>

//     </div>
//   )
// }
// export default App